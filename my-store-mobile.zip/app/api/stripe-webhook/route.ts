import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createClient } from '@supabase/supabase-js'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!, // server-side ONLY
  { auth: { persistSession: false } }
)

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature')!
  const raw = await req.text()

  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(raw, sig, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err: any) {
    return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const s = event.data.object as Stripe.Checkout.Session
    const userId = s.client_reference_id || null
    const amount = (s.amount_total ?? 0) / 100
    const sessionId = s.id
    const paymentIntent = typeof s.payment_intent === 'string' ? s.payment_intent : s.payment_intent?.id || null

    if (userId) {
      const { error } = await supabase.rpc('stripe_upsert_paid', {
        in_session_id: sessionId,
        in_payment_intent: paymentIntent,
        in_amount: amount,
        in_user_uuid: userId
      })
      if (error) return new NextResponse(`DB error: ${error.message}`, { status: 500 })
    }
  }

  return NextResponse.json({ received: true })
}
