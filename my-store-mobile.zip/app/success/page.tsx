'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export default function Success() {
  const [orders, setOrders] = useState<any[]>([])

  useEffect(() => {
    supabase.rpc('get_my_recent_orders', { in_limit: 5 })
      .then(({ data, error }) => {
        if (error) console.error(error)
        setOrders(data || [])
      })
  }, [])

  return (
    <main style={{ padding: 24 }}>
      <h1>Thanks! 🎉</h1>
      <p>Your recent orders:</p>
      <pre style={{ background:'#f6f6f6', padding:12, borderRadius:8 }}>{JSON.stringify(orders, null, 2)}</pre>
      <a href="/">Back home</a>
    </main>
  )
}
